package com.study.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {
	
	@GetMapping("/admin/main")
    public String adminMainPage() {
        return "admin-main"; // 어드민 페이지에서 렌더링할 admin-main.html 파일 이름
    }
}
