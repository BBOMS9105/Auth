package com.study.springboot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
	
	@ModelAttribute("users")
	public List<User> users() {
	    List<User> users = new ArrayList<>();
	    users.add(new User("admin", "password", "admin"));
	    users.add(new User("user", "password", "user"));
	    users.add(new User("special", "password", "special"));
	    return users;
	}
	
    @GetMapping("/login-form")
    public String getLoginForm(Model model) {
    	 model.addAttribute("loginForm", new LoginForm());
    	 return "login-form";
    }

    @PostMapping("/login")
    public String doLogin(@ModelAttribute("loginForm") LoginForm loginForm,
            @ModelAttribute("users") List<User> users, Model model) {
        User matchedUser = null;
        for (User user : users) {
            if (user.getId().equals(loginForm.getId()) && user.getPw().equals(loginForm.getPw())) {
                matchedUser = user;
                break;
            }
        }
        if (matchedUser == null) {
            model.addAttribute("error", "아이디 또는 비밀번호가 일치하지 않습니다");
            return "login-form";
        } else {
            String viewName = "redirect:/user/main";
            if ("admin".equals(matchedUser.getRole())) {
                viewName = "redirect:/admin/main"; // 어드민 전용 메인 페이지로 리다이렉션
            } else if ("special".equals(matchedUser.getRole())) {
                viewName = "redirect:/special/main";
            } else {
            	viewName = "redirect:/user/main";
            }
            model.addAttribute("user", matchedUser);
            return viewName;
        }
    }
}