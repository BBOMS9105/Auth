package com.study.springboot;

public class User {
	
	private String id;	 // id
	private String pw;   // password
	private String role; 
	
	public User(String id, String pw, String role) {
		this.id = id;
		this.pw = pw;
		this.role = role;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getPw() {
		return pw;
	}
	
	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getRole() {
		return role;
	}
	
	 public boolean matchPw(String pw) {
	        return this.pw.equals(pw);
	    }
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
